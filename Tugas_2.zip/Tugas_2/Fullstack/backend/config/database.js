import { Sequelize } from "sequelize";

const db = new Sequelize('favoritdb', 'root', '', {
    host: 'localhost',
    dialect: 'mysql'
});

export default db;